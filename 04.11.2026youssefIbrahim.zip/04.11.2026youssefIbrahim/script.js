//=========================
//Create HTML from an array dynamically 
//=========================
/*

   The basic idea or patterm of this is: 
   1. The array that hold this data
   2. An event changes the array
   3. Afunction to update the whole list based on the yrray
*/


//REferences to all elements

//=========================
//Create HTML from an array dynamically 
//=========================
/*

   The basic idea or patterm of this is: 
   1. The array that hold this data
   2. An event changes the array
   3. Afunction to update the whole list based on the yrray
*/


// References to DOM elements
const enemyHealth = document.querySelector('#enemy-health');
const spellCount = document.querySelector('#spell-count');
const spellName = document.querySelector('#spell-name');
const spellDamage = document.querySelector('#spell-damage');
const addSpell = document.querySelector('#add-spell');
const spellList = document.querySelector('#spell-list');

// Global variables
const spells = [
    { spellName: 'Ember',
        damage: 8
    },
    { spellName: 'Spark',
        damage: 2
    }
];

let enemyHealthPoints = 30;
console.log("hdjd")
// Draw the whole list of spells from the array
function renderSpells() {
    
    // Remove the old list first before we add the new one
    spellList.innerHTML = '';

    for (let i = 0; i < spells.length; i++) {
        const spell = spells[i];

        // Create an new "li" item for each spell and fill with content
        const row = document.createElement("li");

        // Create a "span" in the "li" for the text
        const text = document.createElement('span');
        text.innerText = `${spell.spellName} (${spell.damage} damage)`;

        // Create a button for casting
        const castButton = document.createElement('button');
        castButton.innerText = 'Cast';
        castButton.onclick = function () {
         
            enemyHealthPoints -= spell.damage;
        if (enemyHealthPoints < 0)
            {
                enemyHealthPoints = 0;
            }

            //update the actual enemmy health
            enemyHealth.innerText = enemyHealthPoints;
        }

        // Create a button for deleting the spell
        const deleteButton = document.createElement('button')
        deleteButton.innerText = 'X';
        deleteButton.onclick = function() {
            spells.splice(i, 1);
            renderSpells();
        }

        // Put all together inside the "li" and then add this to the "ul" element
        row.appendChild(text);
        row.appendChild(castButton);
        row.appendChild(deleteButton);
        spellList.appendChild(row); // Adds our "li" to the "ul"

     // Alternative Way:
    // ------------------
    // spellList.innerHTML +=
    // `
        // <li>
            // <span>${spell.spellName} (${spell.damage} damage</span>
            // <button>Cast</button>
            // <button>X</button>
        // </li>
    // `

    }

    spellCount.innerText = spells.length;
}
renderSpells();


// Read the input fields and add new spells
//-----------------------------------------
/*
we will use an anonymous function (Function without a name)
 as the button  only needs this function

 These functions we attach to html element with event listners get as frist parameter 
 automatically the event object from the browser 

*/
addSpell.onclick = function(event) 
{
 const damage = +spellDamage.value; 
 const name = spellName.value;

 if (name === '' || damage < 1 ) {
alert('Wrong inputs!');
return;    
 }
spells.push(
{
    spellName: name,
    damage: damage, 
}

);

//Clear fields after we added the spell to array 
spellDamage.value = '';
spellName.value= '';

//Here we re render the whole list of spells 
renderSpells();
}